package com.heer.multiplayer.model

data class User(
    var name: String,
    val reqType: String
)