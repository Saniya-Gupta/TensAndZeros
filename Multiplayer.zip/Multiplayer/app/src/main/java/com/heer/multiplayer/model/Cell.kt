package com.heer.multiplayer.model

class Cell( val i: Int, val j: Int)